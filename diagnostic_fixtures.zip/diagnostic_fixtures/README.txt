Glide automated diagnostic fixtures. Generated for GlideA diagnostics.
Files are intentionally tiny except 90-92 settings fixtures used to prove preview/quality behavior.
Codec-dependent entries are expected to pass only when Windows/WIC has the corresponding decoder.
